﻿(function ($) {

    /**
    * 扩展String方法
    */
    $.extend(String.prototype, {
        isPositiveInteger: function () {
            return (new RegExp(/^[1-9]\d*$/).test(this));
        },
        isInteger: function () {
            return (new RegExp(/^\d+$/).test(this));
        },
        isNumber: function (value, element) {
            return (new RegExp(/^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/).test(this));
        },
        trim: function () {
            return this.replace(/(^\s*)|(\s*$)|\r|\n/g, "");
        },
        /**合并多个空白为一个空白*/
        ResetBlank: function () {
            return this.replace(/\s+/g, ' ');
        },
        /**保留数字*/
        GetNumber: function () {
            return this.replace(/[^\d]/g, '');
        },
        /**保留中文*/
        GetCN: function () {
            var regEx = /[^\u4e00-\u9fa5\uf900-\ufa2d]/g;
            return this.replace(regEx, '');
        },
        GetLen: function () {
            var regEx = /^[\u4e00-\u9fa5\uf900-\ufa2d]+$/;
            if (regEx.test(this)) {
                return this.length * 2;
            } else {
                var oMatches = this.match(/[\x00-\xff]/g);
                var oLength = this.length * 2 - oMatches.length;
                return oLength;
            }
        },
        /**获取文件全名*/
        GetFileName: function () {
            var regEx = /^.*\/([^\/\?]*).*$/;
            return this.replace(regEx, '$1');
        },
        /**获取文件扩展名*/
        GetExtensionName: function () {
            var regEx = /^.*\/[^\/]*(\.[^\.\?]*).*$/;
            return this.replace(regEx, '$1');
        },
        startsWith: function (pattern) {
            return this.indexOf(pattern) === 0;
        },
        endsWith: function (pattern) {
            var d = this.length - pattern.length;
            return d >= 0 && this.lastIndexOf(pattern) === d;
        },
        replaceSuffix: function (index) {
            return this.replace(/\[[0-9]+\]/, '[' + index + ']').replace('#index#', index);
        },
        trans: function () {
            return this.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"');
        },
        encodeTXT: function () {
            return (this).replaceAll('&', '&amp;').replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll(" ", "&nbsp;");
        },
        replaceAll: function (os, ns) {
            return this.replace(new RegExp(os, "gm"), ns);
        },
        replaceTm: function ($data) {
            if (!$data) return this;
            return this.replace(RegExp("({[A-Za-z_]+[A-Za-z0-9_]*})", "g"), function ($1) {
                return $data[$1.replace(/[{}]+/g, "")];
            });
        },
        replaceTmById: function (_box) {
            var $parent = _box || $(document);
            return this.replace(RegExp("({[A-Za-z_]+[A-Za-z0-9_]*})", "g"), function ($1) {
                var $input = $parent.find("#" + $1.replace(/[{}]+/g, ""));
                return $input.val() ? $input.val() : $1;
            });
        },
        isFinishedTm: function () {
            return !(new RegExp("{[A-Za-z_]+[A-Za-z0-9_]*}").test(this));
        },
        skipChar: function (ch) {
            if (!this || this.length === 0) { return ''; }
            if (this.charAt(0) === ch) { return this.substring(1).skipChar(ch); }
            return this;
        },
        isValidPwd: function () {
            return (new RegExp(/^([_]|[a-zA-Z0-9]){6,32}$/).test(this));
        },
        isValidMail: function () {
            return (new RegExp(/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/).test(this.trim()));
        },
        isSpaces: function () {
            for (var i = 0; i < this.length; i += 1) {
                var ch = this.charAt(i);
                if (ch != ' ' && ch != "\n" && ch != "\t" && ch != "\r") { return false; }
            }
            return true;
        },
        isPhone: function () {
            return (new RegExp(/(^([0-9]{3,4}[-])?\d{3,8}(-\d{1,6})?$)|(^\([0-9]{3,4}\)\d{3,8}(\(\d{1,6}\))?$)|(^\d{3,8}$)/).test(this));
        },
        isUrl: function () {
            return (new RegExp(/^[a-zA-z]+:\/\/([a-zA-Z0-9\-\.]+)([-\w .\/?%&=:]*)$/).test(this));
        },
        isExternalUrl: function () {
            return this.isUrl() && this.indexOf("://" + document.domain) == -1;
        },
        toUnicode: function () {
        	var str = this;
            //转成unicode
            var a = [], i = 0;
            for (; i < str.length; ) a[i] = ("00" + str.charCodeAt(i++).toString(16)).slice(-4);
            return "\\u" + a.join("\\u");
        },
        toUnEscape: function (str) {
            //解析unicode
            return unescape(str.replace(/\\/g, "%"));
        },
        toParseDate:function(){
        	/*字符串格式"yyyy-MM-dd"转成日期时间*/
        	var strTime = this;
        	return new Date(Date.parse(strTime.replace(/-/g,   "/"))); 
        }
    });

    /**Number扩展方法*/
    $.extend(Number.prototype, {
        /** 检查当前数值是否处于指定的区间之内，如果当前值处于区间内，直接返回该值；
        * 否则返回min或max，取决于当前值超出了哪一个边界。注意：该方法返回约束值，但 
        * 不改变当前值。 
        */
        constrain: function (min, max) {
            return Math.min(Math.max(this, min), max);
        }
    });


    /**       
    * 对Date的扩展，将 Date 转化为指定格式的String       
    * 月(M)、日(d)、12小时(h)、24小时(H)、分(m)、秒(s)、周(E)、季度(q) 可以用 1-2 个占位符       
    * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)       
    * eg:       
    * (new Date()).format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423       
    * (new Date()).format("yyyy-MM-dd E HH:mm:ss") ==> 2009-03-10 二 20:09:04       
    * (new Date()).format("yyyy-MM-dd EE hh:mm:ss") ==> 2009-03-10 周二 08:09:04       
    * (new Date()).format("yyyy-MM-dd EEE hh:mm:ss") ==> 2009-03-10 星期二 08:09:04       
    * (new Date()).format("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18       
    */
    $.extend(Date.prototype, {
        format: function (fmt) {
            var o = {
                "M+": this.getMonth() + 1, //月份           
                "d+": this.getDate(), //日           
                "h+": this.getHours() % 12 == 0 ? 12 : this.getHours() % 12, //小时,12小时制           
                "H+": this.getHours(), //小时,24小时制           
                "m+": this.getMinutes(), //分           
                "s+": this.getSeconds(), //秒           
                "q+": Math.floor((this.getMonth() + 3) / 3), //季度           
                "S": this.getMilliseconds() //毫秒           
            };
            var week = {
                "0": "\u65e5",
                "1": "\u4e00",
                "2": "\u4e8c",
                "3": "\u4e09",
                "4": "\u56db",
                "5": "\u4e94",
                "6": "\u516d"
            };
            if (/(y+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
            }
            if (/(E+)/.test(fmt)) {
                fmt = fmt.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[this.getDay() + ""]);
            }
            for (var k in o) {
                if (new RegExp("(" + k + ")").test(fmt)) {
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
                }
            }
            return fmt;
        },
        clone:function(){
            //返回一个数值相同的新Date对象 
            var $clone = new Date();
            $clone.setFullYear(this.getFullYear());
            $clone.setMonth(this.getMonth());
            $clone.setDate(this.getDate());
            $clone.setHours(this.getHours());
            $clone.setMinutes(this.getMinutes());
            $clone.setSeconds(this.getSeconds());
            $clone.setMilliseconds(this.getMilliseconds());
            return $clone; 
        },
        addDays:function(day){
            //追加天数
            this.setDate(this.getDate() + day);
            return this;
        },
        addWeeks:function(week){
            //追加周
            this.addDays(week * 7);
            return this;
        },
        addMonths:function(month){
            this.setMonth(this.getMonth() + month);
            return this;
        },
        addYears:function(year){
            //追加年
            this.setFullYear(this.getFullYear() + year);
            return this;
        },
        getDaysByMonth: function () {
            //获取当前年月份的天数
            return new Date(this.getFullYear(), this.getMonth()+1, 0).getDate();
        },
        getDaysInMonth: function (year, month) {
            //获取指定年月份的天数
            return new Date(year, month+1, 0).getDate();
        },
        getMonthByzhcn: function () {
            var months = "一月,二月,三月,四月,五月,六月,七月,八月,九月,十月,十一月,十二月".split(",");
            return months[this.getMonth()];
        },
        getWeekDayByzhcn: function () {
            var weekdays = "星期日,星期一,星期二,星期三,星期四,星期五,星期六".split(",");
            return weekdays[this.getDay()];
        },
        getMonthNameByEN: function () {
            var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            return monthNames[this.getMonth()];
        },
        getAbbrMonthNameByEN: function () {
            var abbrMonthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            return abbrMonthNames[this.getMonth()];
        },
        getWeekDay: function (prefix) {
            //获取一周的某天
            var weekdays = "日,一,二,三,四,五,六".split(",");
            return prefix + weekdays[this.getDay()];
        },
        getWeekDay1: function () {
            //获取星期几
            return this.getWeekDay("星期");
        },
        getWeekDay2: function () {
            //获取周几
            return this.getWeekDay("周");
        },
        getWeekDayByEN: function () {
            var dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            return dayNames[this.getDay()];
        },
        getAbbrWeekDayByEN: function () {
            var abbrDayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            return abbrDayNames[this.getDay()];
        },
        isLeapYear: function () {
            //检查当前年是否是闰年
            var y = this.getFullYear();
            return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
        },
        getDayOfYear: function () {
            //获取一年多少天
            var tmpdtm = new Date(this.getFullYear(), 1, 1);
            return Math.floor((this.getTime() - tmpdtm.getTime()) / 86400000);
        },
        getWeekOfYear: function () {
            //获取一年有多少周
            return Math.ceil(this.getDayOfYear() / 7);
        },
        diff: function (interval, objDate) {
            //若参数不足或 objDate 不是日期类型则回传 undefined  
            if (arguments.length < 2 || objDate.constructor != Date) { return undefined; }
            switch (interval) {
                //计算秒差                                                                       
                case 's': return parseInt((objDate - this) / 1000);
                    //计算分差  
                case 'n': return parseInt((objDate - this) / 60000);
                    //计算时差  
                case 'h': return parseInt((objDate - this) / 3600000);
                    //计算日差  
                case 'd': return parseInt((objDate - this) / 86400000);
                    //计算周差  
                case 'w': return parseInt((objDate - this) / (86400000 * 7));
                    //计算月差  
                case 'm': return (objDate.getMonth() + 1) + ((objDate.getFullYear() - this.getFullYear()) * 12) - (this.getMonth() + 1);
                    //计算年差  
                case 'y': return objDate.getFullYear() - this.getFullYear();
                    //输入有误  
                default: return undefined;
            }
        }

    });

    var userAgent = navigator.userAgent.toLowerCase();
    var info = navigator.platform;

    function isMobile() {
        var mobileAgents = ['Windows CE', 'iPod', 'Symbian', 'iPhone', 'BlackBerry', 'Android', 'Windows Phone'];
        var sUserAgent = userAgent;
        if (sUserAgent.indexOf('Android') > -1
            && (sUserAgent.indexOf('ERD79') > -1 || sUserAgent.indexOf('MZ60') > -1
            || sUserAgent.indexOf('GT-P7') > -1 || sUserAgent.indexOf('SCH-P7') > -1)) { return false; } else {

            if (location.href.indexOf('pc') == -1) {
                for (var i = 0; i < mobileAgents.length; i++) {
                    if (sUserAgent.indexOf(mobileAgents[i]) > -1) {
                        return true;
                    }
                }
            } else {
                //ipad时
                return false;
            }

        }
    }

    //jquery 1.9 之后移除了browser,下面一行代码是为了兼容
    //$.browser = $.browser || $.support;

    $.extend($.support, {
        getUserAgent: function () { return navigator.userAgent },
        msie: /msie/.test(userAgent),
        msie10: /msie\s+10\.0/i.test(userAgent),
        msie9: /msie\s+9\.0/i.test(userAgent),
        msie8: /msie\s+8\.0/i.test(userAgent),
        msie7: /msie\s+7\.0/i.test(userAgent),
        msie6: !this.msie8 && !this.msie7 && /msie\s+6\.0/i.test(userAgent),
        iPad: userAgent.toString().match(/iPad/i) != null,
        isMobile: isMobile() == true,
        gc: function () {
            if (this.msie6) {
                try {
                    document.execCommand("BackgroundImageCache", false, true);
                } catch (e) { }
            }
            //清理浏览器内存,只对IE起效
            if (this.msie) {
                window.setInterval("CollectGarbage();", 10000);
            }
        }
    });

    //平台、设备和操作系统,检测平台
    $.system = {
        getInfo: function () { return navigator.platform; },
        win: info.indexOf("Win") == 0,
        mac: info.indexOf("Mac") == 0,
        xll: (info == "X11") || (info.indexOf("Linux") == 0)
    };

    //调试
    $.debug = {
    	status:true,
        log: function (msg) {
        	if(!this.status)return;
            if (typeof (console) != "undefined")
                console.log(msg);
            else
                alert(msg);
        },
        dir: function (obj) {
        	if(!this.status)return;
            if (typeof (console) != "undefined")
                console.dir(obj);
            else
                alert(obj);
        },
        error: function (msg) {
        	if(!this.status)return;
            if (typeof (console) != "undefined")
                console.error(msg);
            else
                alert("error: " + msg);
        }
    };


    /** 
    * You can use this map like this:
    * var myMap = $.MapExt.newInstance();
    * myMap.put("key","value");
    * var value = myMap.get("key");
    * myMap.remove("key");
    */
    $.MapExt = {
        newInstance: function () {
            return new Map();
        }
    };

    function Map() {

        this.elements = new Array();

        this.size = function () {
            return this.elements.length;
        };

        this.isEmpty = function () {
            return (this.elements.length < 1);
        };

        this.clear = function () {
            this.elements = new Array();
        };

        this.put = function (_key, _value) {
            this.remove(_key);
            this.elements.push({ key: _key, value: _value });
        };

        this.remove = function (_key) {
            try {
                for (var i = 0; i < this.elements.length; i++) {
                    if (this.elements[i].key == _key) {
                        this.elements.splice(i, 1);
                        return true;
                    }
                }
            } catch (e) {
                return false;
            }
            return false;
        };

        this.get = function (_key) {
            try {
                for (var i = 0; i < this.elements.length; i++) {
                    if (this.elements[i].key == _key) { return this.elements[i].value; }
                }
            } catch (e) {
                return null;
            }
        };

        this.element = function (_index) {
            if (_index < 0 || _index >= this.elements.length) { return null; }
            return this.elements[_index];
        };

        this.containsKey = function (_key) {
            try {
                for (var i = 0; i < this.elements.length; i++) {
                    if (this.elements[i].key == _key) {
                        return true;
                    }
                }
            } catch (e) {
                return false;
            }
            return false;
        };

        this.values = function () {
            var arr = new Array();
            for (var i = 0; i < this.elements.length; i++) {
                arr.push(this.elements[i].value);
            }
            return arr;
        };

        this.keys = function () {
            var arr = new Array();
            for (var i = 0; i < this.elements.length; i++) {
                arr.push(this.elements[i].key);
            }
            return arr;
        };

    };

    //IE浏览器自动开启清理内存
    $.support.gc();

})(window.jQuery || jQuery);