/*
	说明：admin-system.js 后端系统全局配置
	时间：2015.10.14
	记录：
		list - 
				checkbox 操作，
		form - 
				ajaxFormSubmit 提交表单
				ajaxFormSubmitValidator 提交表单并带数据校验 (http://amazeui.org/javascript/validator)
		amazeUi弹出层 - 
				amAlert 提示弹出框
				amConfirm 选择弹出框
		
	
 */

/************************************ list ************************************/ 
/**   
 * 列表页checkbox操作 
 */
$(function() {
   $(".keyCheckAll").click(function() {
	    var isChecked = $(this).prop("checked");
	    $(".keyCheck").prop("checked", isChecked); 
    }); 
   
   $(".deletes").click(function() { 
	   var check = getChecked(); 
	   if(check.length > 0){ 
			$.ajax({
			   type: "POST",
			   url : $(this).attr("data-url"),
			   data: "ids="+check,
			   success: function(msg){ 
				   if(msg.status == 'success'){
					   window.location = window.location;
				   }else{ 
					   amAlert("错误","操作失败.!");   
				   } 
			   }
			}); 
	   } else {
		   amAlert("错误","请选择数据,再进行删除操作.!");
	   } 
   }); 

   $(".delete").click(function() { 
	   var url = $(this).attr("data-url");
	   amConfirm(
			   "删除提示",
			   "确认要删除当前数据吗.删除后数据不可恢复。",
			   function(){ 
					$.ajax({
					   type: "POST",
					   url : url, 
					   success: function(msg){  
						   if(msg.status == 'success'){
							   window.location = window.location;
						   }else{
							   amAlert("错误","操作失败.!");  
						   } 
					   }
					});  
			   },function(){}
	   );
   }); 
});

function getChecked(){
	var check = ""; 
	$(".keyCheck:checked").each(function(){ 
    	check = check + $(this).val()+","; 
	});
	return check;
} 

/************************************ form ************************************/ 
/**   
 * ajax提交form表单 (带数据验证)
 * @param listUrl 提交表单后的返回路径
 */
function ajaxFormSubmitValidator(listUrl){    
	if($('#myform').data('amui.validator').isFormValid()){		 
		$.ajax({
			type: "POST",
			url : $("#myform").attr("action"),
			data: $("#myform").serialize(),
			success: function(msg){ 
				if(msg.status == 'success'){
					window.location = listUrl;
				}else{ 
					amAlert("错误","操作失败.!");
				} 
			}
		});
	}  
}

/**
 * ajax提交form表单 (不带数据验证)
 * @param listUrl 提交表单后的返回路径
 */
function ajaxFormSubmit(listUrl){     	 
	$.ajax({
		type: "POST",
		url : $("#myform").attr("action"),
		data: $("#myform").serialize(),
		success: function(msg){ 
			if(msg.status == 'success'){
				window.location = listUrl;
			}else{ 
				amAlert("错误","操作失败.!");
			} 
		}
	}); 
}


/************************************ amazeUi 弹出层 ************************************/
/**   
 * amAlert 提示框
 * @param title 标题
 * @param body  内容 
 */
function amAlert(title,body){ 
	$('#am-alert').find(".am-modal-hd").html(title);
	$('#am-alert').find(".am-modal-bd").html(body);
	$('#am-alert').modal({relatedTarget: this}); 
}
/**   
 * amConfirm 选择弹出层
 * @param title 标题
 * @param body  内容
 * @param onConfirm  确定事件
 * @param onCancel   取消事件 
 */
function amConfirm(title,body,onConfirm,onCancel){  
	$('#am-confirm').find(".am-modal-hd").html(title);
	$('#am-confirm').find(".am-modal-bd").html(body);
    var $confirm = $('#am-confirm');
    var confirm = $confirm.data('am.modal');   
    if (confirm) {
      confirm.options.onConfirm =  onConfirm;
      confirm.options.onCancel =  onCancel;
      confirm.toggle(this);
    } else {
      $confirm.modal({
        relatedElement: this,
        onConfirm: onConfirm,
        onCancel: onCancel
      });
    }
}



